var anscombe = [
    { experiment: 1, x: 10, y: 8.04 }, 
    { experiment: 1, x:  8, y: 6.95 }, 
    { experiment: 1, x: 13, y: 7.58 }, 
    { experiment: 1, x:  9, y: 8.81 }, 
    { experiment: 1, x: 11, y: 8.33 }, 
    { experiment: 1, x: 14, y: 9.96 }, 
    { experiment: 1, x:  6, y: 7.24 }, 
    { experiment: 1, x:  4, y: 4.26 }, 
    { experiment: 1, x: 12, y: 10.84 }, 
    { experiment: 1, x:  7, y: 4.82 }, 
    { experiment: 1, x:  5, y: 5.68 }, 
    { experiment: 2, x: 10, y: 9.14 }, 
    { experiment: 2, x:  8, y: 8.14 }, 
    { experiment: 2, x: 13, y: 8.74 }, 
    { experiment: 2, x:  9, y: 8.77 }, 
    { experiment: 2, x: 11, y: 9.26 }, 
    { experiment: 2, x: 14, y: 8.1 }, 
    { experiment: 2, x:  6, y: 6.13 }, 
    { experiment: 2, x:  4, y: 3.1 }, 
    { experiment: 2, x: 12, y: 9.13 }, 
    { experiment: 2, x:  7, y: 7.26 }, 
    { experiment: 2, x:  5, y: 4.74 }, 
    { experiment: 3, x: 10, y: 7.46 }, 
    { experiment: 3, x:  8, y: 6.77 }, 
    { experiment: 3, x: 13, y: 12.74 }, 
    { experiment: 3, x:  9, y: 7.11 }, 
    { experiment: 3, x: 11, y: 7.81 }, 
    { experiment: 3, x: 14, y: 8.84 }, 
    { experiment: 3, x:  6, y: 6.08 }, 
    { experiment: 3, x:  4, y: 5.39 }, 
    { experiment: 3, x: 12, y: 8.15 }, 
    { experiment: 3, x:  7, y: 6.42 }, 
    { experiment: 3, x:  5, y: 5.73 }, 
    { experiment: 4, x:  8, y: 6.58 }, 
    { experiment: 4, x:  8, y: 5.76 }, 
    { experiment: 4, x:  8, y: 7.71 }, 
    { experiment: 4, x:  8, y: 8.84 }, 
    { experiment: 4, x:  8, y: 8.47 }, 
    { experiment: 4, x:  8, y: 7.04 }, 
    { experiment: 4, x:  8, y: 5.25 }, 
    { experiment: 4, x: 19, y: 12.5 }, 
    { experiment: 4, x:  8, y: 5.56 }, 
    { experiment: 4, x:  8, y: 7.91 }, 
    { experiment: 4, x:  8, y: 6.89 }
];

// select main div
var mainDiv = d3.select("#mainDiv");

// append four svg elements and assign node to variables (e.g., var svg1 = ...)


// select all "svg" elements from mainDiv and 
// set height attr to 330 and width attr to 430


// for each of the four experiments plot a scatterplot based on
// the data (HINT: selectAll circled, join with data, use enter() and append("circle")
// and set attr cx to x and attr cy to y. Each experiment needs to be in a separate
// svg element) Make any adjustments to y for the scatterplots to have (0, 0) on the
// lower left corner (instead of the upper left corner of the canvas)


// select all "circle" in the mainDiv and set the radius attr to 3


// append two text elements to all "svg" elements in mainDiv to write the x and y
// axis labels

// append two line elements to all "svg" elements in mainDiv to draw
// the two axes -- remember to set att "stroke" to "black"
