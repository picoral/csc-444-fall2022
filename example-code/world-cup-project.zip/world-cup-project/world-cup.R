# load libraries
library(tidyverse)

# read data in
world_cup <- read_csv("data/WorldCupMatches.csv") %>% 
  distinct()

# what is win conditions?
world_cup %>% 
  count(`Win conditions`)

# has attendance changed over the years?
world_cup %>% 
  ggplot(aes(y = Attendance,
             x = Year)) + 
  geom_point()

# create winner column
world_cup <- world_cup %>% 
  mutate(winner = case_when(`Home Team Goals` > `Away Team Goals` ~ `Home Team Name`,
                            `Away Team Goals` > `Home Team Goals`  ~ `Away Team Name`,
                            TRUE ~ gsub("\\s.+", "", `Win conditions`)),
         winner = gsub(" FR", "", winner))

# count winners
world_cup %>% 
  filter(Stage == "Final") %>% 
  count(winner, sort = TRUE)

# get final matches goals
final_matches <- world_cup %>% 
  filter(Stage == "Final") %>%  
  select(Year, `Home Team Name`, `Away Team Name`, `Home Team Goals`, `Away Team Goals`) %>% 
  pivot_longer(cols = 2:3,
               values_to = "country") %>% 
  mutate(goals = if_else(name == "Home Team Name",
                         `Home Team Goals`,
                         `Away Team Goals`)) %>% 
  select(Year, country, goals, name)

# plot final matches goals
final_matches %>% 
  ggplot(aes(x = Year,
             y = goals,
             fill = name)) +
  geom_col(position = "dodge")

