// create div and svg
var mainDiv = d3.select("body").append("div");
var mySvg = mainDiv.append("svg");
mySvg.attr("width", "400").attr("height", 400);

function getColor(n) {
    if (n > 5) {
        return "Crimson"
    } else { return "DarkBlue"}
};

for (var i = 0; i < 8; i++) {
    for (var j = 0; j < 8; j++) {
        mySvg.append("circle")
             .attr("cx", i * 20 + 10)
             .attr("cy", j * 20 + 10)
             .attr("r", 5)
             .attr("fill", getColor(j));
    }
}