// create div and svg
var mainDiv = d3.select("body").append("div");
var mySvg = mainDiv.append("svg");
mySvg.attr("width", "400").attr("height", 400);

var myData = [[1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0],
              [1, 1, 0, 0, 0, 0, 0, 0]];


for (var i = 0; i < 8; i++) {
    for (var j = 0; j < 8; j++) {
        if (myData[j][i] == 0) {
            mySvg.append("circle")
             .attr("cx", i * 20 + 10)
             .attr("cy", j * 20 + 10)
             .attr("r", 5)
             .attr("fill", "DarkBlue");
        } else {
            mySvg.append("rect")
             .attr("x", i * 20 + 5)
             .attr("y", j * 20 + 5)
             .attr("width", 10)
             .attr("height", 10)
             .attr("fill", "DarkBlue");
        };
        
    };
};