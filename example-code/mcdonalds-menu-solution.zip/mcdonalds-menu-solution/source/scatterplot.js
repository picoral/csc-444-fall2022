// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "McDonald's Menu Items",
    width: 850,
    height: 300,
    padding: 10,
    data: [
        {
          name: "menu",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/mcdonalds_menu.csv",
          format: { type: "csv"}
        }
    ],
    scales: [
        {
            name: "xScale",
            type: "linear",
            domain: { data: "menu", field: "calories"  },
            range: "width"

        },
        {
            name: "yScale",
            type: "linear",
            domain: { data: "menu", field: "total_fat" },
            range: "height"
        }
    ],
    axes: [
        {
            scale: "xScale",
            orient: "bottom",
            title: "Calories",
            grid: true
        },
        {
            scale: "yScale",
            orient: "left",
            title: "Total Fat",
            grid: true
        }
    ],
    marks: [
        {
            type: "symbol",
            from: { data: "menu" },
            encode: {
                enter: {
                    x: { field: "calories", scale: "xScale" },
                    y: { field: "total_fat", scale: "yScale" }
                }
            } 
        }
    ],
    title: {
        text: "Calories vs. Total Fat in Grams"
    }
};

// create runtime
var runtime = vega.parse(spec);

// create view
var scatterplot = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#scatterplot")
                   .hover();

// run it
scatterplot.run();