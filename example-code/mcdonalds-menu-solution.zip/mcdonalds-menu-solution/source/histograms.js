// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "McDonald's Menu Items",
    width: 850,
    height: 300,
    padding: 10,
    data: [
        {
          name: "menu",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/mcdonalds_menu.csv",
          format: { type: "csv"}
        },
        {
            name: "calories_bins",
            source: "menu",
            transform: [
                {
                    type: "extent",
                    field: "calories",
                    signal: "calories_max_min"
                },
                {
                    type: "bin",
                    signal: "bins_for_calories",
                    field: "calories",
                    extent: { signal: "calories_max_min" },
                    maxbins: 20
    
                },
                {
                    type: "aggregate",
                    groupby: ["bin0", "bin1"]
                }
            ]
        },
        {
            name: "total_fat_bins",
            source: "menu",
            transform: [
                {
                    type: "extent",
                    field: "total_fat",
                    signal: "total_fat_max_min"
                },
                {
                    type: "bin",
                    signal: "bins_for_fat",
                    field: "total_fat",
                    extent: { signal: "total_fat_max_min" },
                    maxbins: 20
    
                },
                {
                    type: "aggregate",
                    groupby: ["bin0", "bin1"]
                }
            ]
        }
    ],
    scales: [
        {
            name: "xScale_calories",
            type: "linear",
            bins: { signal: "bins_for_calories" },
            domain: { signal: "[bins_for_calories.start, bins_for_calories.stop]" },
            range: [0, 400]

        },
        {
            name: "yScale_calories",
            type: "linear",
            domain: { data: "total_fat_bins", field: "count" },
            range: "height"
        },
        {
            name: "xScale_fat",
            type: "linear",
            bins: { signal: "bins_for_fat" },
            domain: { signal: "[bins_for_fat.start, bins_for_fat.stop]" },
            range: [450, 850]
        },
        {
            name: "yScale_fat",
            type: "linear",
            domain: { data: "total_fat_bins", field: "count" },
            range: "height"
        }
    ],
    axes: [
        {
            scale: "xScale_calories",
            orient: "bottom",
            title: "Calories",
            labelFontSize: 8,
            grid: true
        },
        {
            scale: "yScale_calories",
            orient: "left",
            title: "count",
            grid: true
        },
        {
            scale: "xScale_fat",
            orient: "bottom",
            title: "Total Fat in Grams",
            grid: true
        },
        {
            scale: "yScale_fat",
            orient: "right",
            title: "count",
            grid: true
        }
    ],
    marks: [
        {
            type: "rect",
            from: { data: "calories_bins" },
            encode: {
                enter: {
                    x: { field: "bin0", scale: "xScale_calories" },
                    x2: { field: "bin1", scale: "xScale_calories" },
                    y: { field: "count", scale: "yScale_calories" },
                    y2: { value: 0, scale: "yScale_calories" }
                }
            } 
        },
        {
            type: "rect",
            from: { data: "total_fat_bins" },
            encode: {
                enter: {
                    x: { field: "bin0", scale: "xScale_fat" },
                    x2: { field: "bin1", scale: "xScale_fat" },
                    y: { field: "count", scale: "yScale_fat" },
                    y2: { value: 0, scale: "yScale_fat" }
                }
            }

        }
    ],
    title: {
        text: "Distribution of Menu Items"
    }
};

// create runtime
var runtime = vega.parse(spec);

// create view
var histograms = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#histograms")
                   .hover();

// run it
histograms.run();