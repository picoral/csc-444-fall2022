var mainDiv = d3.select("#mainDiv")
var mySvg = mainDiv.append("svg")
                   .attr("width", 200)
                   .attr("height", 200);

mySvg.append("rect")
     .attr("x", 100)
     .attr("y", 100)
     .attr("height", 100)
     .attr("width", 100)
     .attr("fill", "red");