// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "Schools in Arizona",
    width: 400,
    height: 300,
    padding: 10,
    data: [
        {
          name: "ccd",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/ccd_arizona.csv",
          format: { type: "csv"}
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();