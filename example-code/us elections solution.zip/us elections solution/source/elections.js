// Register a discrete color scheme named "basic" that can then be used in Vega specs
vega.scheme('us_parties', ['#f00', '#eee', '#0000CD']);

// create spec
var spec = {
  $schema: "https://vega.github.io/schema/vega/v5.json",
  description: "A map depicting U.S. states.",
  width: 960,
  height: 500,
  autosize: "none",

  data: [
    {
      name: "elections",
      url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/2020-us-elections.csv",
      format: { type: "csv" }
    },
    {
      name: "states",
      url: "https://raw.githubusercontent.com/vega/vega/main/docs/data/us-10m.json",
      format: {"type": "topojson", "feature": "states"},
      transform: [
        {
          type: "lookup",
          from: "elections",
          key: "id",
          fields: ["id"],
          values: ["democrat_difference"]
        }
      ]
    }
  ],
  scales: [
    {
      name: "fillScale",
      type: "linear",
      domain: [-.5, .5],
      range: { scheme: "us_parties" }
    }
  ],
  projections: [
    {
      name: "projection",
      type: "albersUsa"
    }
  ],
  marks: [
    {
      type: "shape",
      from: { data: "states"},
      encode: {
        update: { 
          fill: { field: "democrat_difference", scale: "fillScale" } 
        },
        hover: { tooltip: { signal: "format(datum.democrat_difference, '0.1%')"}}
      },
      transform: [
        { 
          type: "geoshape",
          projection: "projection" }
      ]
    }
  ],
  legends: [
    {
      fill: "fillScale",
      orient: "left-bottom"
    }
  ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();