// Assign the specification to a local variable vlSpec.
var vlSpec = {
    title: "McDonald's Menu Scatter Plot Matrix",
    repeat: {
        row: ["calories", "total_fat", "saturated_fat", "sodium"],
        column: ["calories", "total_fat", "saturated_fat", "sodium"]
    },
    spec: {
        data: {
            url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/mcdonalds_menu.csv",
            format: { type: "csv" }
          },
        mark: "point",
        encoding: {
            x: { 
                field: { repeat: "column" },
                type: "quantitative"
            },
            y: {
                field: { repeat: "row" },
                type: "quantitative"
            }
        }
    }

  };

  // optional argument passed to Vega-Embed to specify Vega-Lite spec. More info at https://github.com/vega/vega-embed
  var opt = {
    "mode": "vega-lite"
  };

  // Embed the visualization in the container with id `vis`
  vegaEmbed("#vis", vlSpec, opt).then(function(result) {
    // Callback receiving the View instance and parsed Vega spec
    // result.view is the View, which resides under the '#vis' element
  }).catch(console.warn);