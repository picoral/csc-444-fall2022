// create spec
var spec = { 
    description: "A bar plot of Ferris Wheels",
    width: 500,
    height: 500,
    padding: 50,
    autosize: "fit",
    data: [
        {
          name: "ferrisWheels",
          url: "https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2022/2022-08-09/wheels.csv",
          format: { type: "csv"}
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();