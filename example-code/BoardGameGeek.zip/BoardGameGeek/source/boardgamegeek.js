// create spec
var spec = { 
    description: "Board Games",
    width: 600,
    height: 400,
    padding: 50,
    autosize: "fit",
    data: [
        {
          name: "boardGames",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/boardGameReview.csv",
          format: { type: "csv"}
        }
    ],
    scales: [
        {
            name: "xScale",
            type: "linear",
            domain: { data: "boardGames", field: "averageUserRating" },
            range: "width"
        },
        {
            name: "yScale",
            type: "linear",
            domain: { data: "boardGames", field: "geekRating" },
            range: "height"
        }
    ],
    axes: [
        {
            scale: "xScale",
            orient: "bottom"
        },
        {
            scale: "yScale",
            orient: "left"
        }
    ],
    marks: [
        {
            type: "symbol",
            from: { data: "boardGames" },
            encode: {
                enter: {
                    x: { field: "averageUserRating", scale: "xScale" },
                    y: { field: "geekRating", scale: "yScale" }
                }
            }
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();