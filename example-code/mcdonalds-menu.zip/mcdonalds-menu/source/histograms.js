// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "McDonald's Menu Items",
    width: 850,
    height: 300,
    padding: 10,
    data: [
        {
          name: "menu",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/mcdonalds_menu.csv",
          format: { type: "csv"}
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var histograms = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#histograms")
                   .hover();

// run it
histograms.run();