// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "McDonald's Menu Items",
    width: 400,
    height: 400,
    padding: 10,
    data: [
        {
          name: "pca",
          url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/menu_pca_results.csv",
          format: { type: "csv"}
        },
        {
            name: "loadings",
            url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/menu_rotation.csv",
            format: { type: "csv" }
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#pca")
                   .hover();

// run it
view.run();