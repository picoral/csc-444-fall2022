// create spec
var spec = { 
    "$schema": "https://vega.github.io/schema/vega/v5.json",
    description: "A plot of lego themes",
    width: 500,
    height: 300,
    padding: 50,
    data: [
        {
            name: "legoThemes",
            url: "https://raw.githubusercontent.com/picoral/csc-444-data/main/lego_themes.json"
        }
    ],
    scales: [
        {
            name: "xScale",
            type: "band",
            domain: { data: "legoThemes", field: "theme"},
            range: "width",
            padding: 0.6
        },
        {
            name: "yScale",
            type: "linear",
            domain: { data: "legoThemes", field: "n" },
            range: "height"
        },
        {
            name: "colorScale",
            type: "ordinal",
            domain: { data: "legoThemes", field: "theme" },
            range: { scheme: "category20" }
        }
    ],
    marks: [
        {
            type: "rect",
            from: { data: "legoThemes"},
            encode: {
                enter: {
                    x: { field: "theme", scale: "xScale"},
                    y2: { value: 0, scale: "yScale"},
                    y: { field: "n", scale: "yScale"},
                    width: { value: 20},
                    fill: { field: "theme", scale: "colorScale"}
                }
            }
        }
    ],
    axes: [
        { 
            scale: "xScale",
            orient: "bottom",
            title: "Theme"
        },
        {
            scale: "yScale",
            orient: "left"
        }
    ],
    title: {
        text: "Number of lego sets by theme"
    },
    legends: [
        {
            fill: "colorScale",
            title: "Theme"
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();