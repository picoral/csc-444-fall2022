// create spec
var spec = { 
    description: "A plot of broadway plays",
    width: 400,
    height: 300,
    padding: 100,
    data: [
        {
          name: "ad",
          url: "https://raw.githubusercontent.com/karananand01/CS444_data/main/advertising_ef.csv",
          format: { type: "csv"},
        },

    ],
    scales: [
        {
            name: "xScale",
            type: "linear",
            domain: { data: "ad", field: "Age" },
            range: "width"
        },
        {
            name: "yScale",
            type: "linear",
            domain: { data: "ad", field: "Area Income" },
            range: "height"
        }
    ],
    axes: [
        {
            scale: "xScale",
            orient: "bottom"
        },
        {
            scale: "yScale",
            orient: "left"
        }
    ]
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();