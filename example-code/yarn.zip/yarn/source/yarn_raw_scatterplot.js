// create spec
var spec = { 
    $schema: "https://vega.github.io/schema/vega/v5.json",
    description: "A plot of yarn",
    width: 400,
    height: 300,
    padding: 10,
    data: [
        {
          name: "yarn",
          url: "https://raw.githubusercontent.com/awalsh17/ravelry_yarns/main/data/yarn.csv",
          format: { type: "csv"},
          transform: [
            {
                type: "filter",
                expr: "datum.rating_average > 0"
            }
          ]
        }
    ],
    scales: [
        {
            name: "xScale",
            domain: { data: "yarn", field: "rating_average" },
            range: "width",
            zero: true
        },
        {
            name: "yScale",
            domain: { data: "yarn", field: "rating_count" },
            range: "height",
            zero: true
        }
    ],
    axes: [
        {
            scale: "xScale",
            orient: "bottom",
            title: "Rating Count"
        },
        {
            scale: "yScale",
            orient: "left",
            title: "Average Rating"
        }
    ],
    marks: [
        {
            type: "symbol",
            from: { data: "yarn" },
            encode: {
                enter: {
                    x: { field: "rating_average", scale: "xScale" },
                    y: { field: "rating_count", scale: "yScale" }
                }
            }
        }
    ],
    title: {
        text: "Yarn",
        subtitle: "Is there a relationship between number of ratings and average rating?"
    }
};

// create runtime
var runtime = vega.parse(spec);

// create view
var view = new vega.View(runtime)
                   .logLevel(vega.Error)
                   .renderer("svg")
                   .initialize("#view")
                   .hover();

// run it
view.run();